#include "Options.h"

int main(int argc, char **argv) {

    PrintHelp(argc, argv) ;
    exit(0) ;

} /* end main */
