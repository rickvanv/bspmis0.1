#ifndef ERRORS_H_DONE

#define ERRORS_H_DONE
void exitwitherror(unsigned int err);

#endif
