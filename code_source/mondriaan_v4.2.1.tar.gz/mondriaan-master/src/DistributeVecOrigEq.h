#ifndef __DistributeVecOrigEq_h__
#define __DistributeVecOrigEq_h__

#include "DistributeVecOrig.h"

long DistributeVecOrigEq(const struct sparsematrix *pM, long int *U, long int *V, const struct opts *pOptions);

#endif /* __DistributeVecOrigEq_h__ */
