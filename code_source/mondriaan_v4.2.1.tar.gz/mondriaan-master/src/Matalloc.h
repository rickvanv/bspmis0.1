#ifndef __Matalloc_h__
#define __Matalloc_h__

#include "Options.h"

/* Function declarations for Matalloc.c */
long **matallocl(int m, int n) ;
void matfreel(long **ppl) ;

#endif /* __Matalloc_h__ */
